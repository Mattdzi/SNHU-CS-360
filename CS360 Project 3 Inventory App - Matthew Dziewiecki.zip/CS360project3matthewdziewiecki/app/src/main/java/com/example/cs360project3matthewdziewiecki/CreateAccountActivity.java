package com.example.cs360project3matthewdziewiecki;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText editNewUsername;
    private EditText editNewPassword;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_account_display);

        editNewUsername = findViewById(R.id.editUsername);
        editNewPassword = findViewById(R.id.editPassword);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);

        databaseHelper = new DatabaseHelper(this);

        btnCreateAccount.setOnClickListener(v -> {
            String newUsername = editNewUsername.getText().toString();
            String newPassword = editNewPassword.getText().toString();

            //This will insert the new user account into the database
            long newRowId = databaseHelper.addUser(newUsername, newPassword);

            if (newRowId != -1) {
                //Account has been created successfully
                Toast.makeText(CreateAccountActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();

                //This will navigate back to the login screen
                Intent intent = new Intent(CreateAccountActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); //This will finish the current activity to remove it from the back stack
            } else {
                //There has been an error will trying to create the account
                Toast.makeText(CreateAccountActivity.this, "Error creating account", Toast.LENGTH_SHORT).show();
            }
        });
    }
}