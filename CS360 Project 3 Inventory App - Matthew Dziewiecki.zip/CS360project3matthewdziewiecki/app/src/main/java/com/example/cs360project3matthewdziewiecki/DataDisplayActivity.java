package com.example.cs360project3matthewdziewiecki;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private GridView gridView;
    private DatabaseHelper databaseHelper;
    private ItemAdapter itemAdapter;
    private int userId;
    private final SparseBooleanArray selectedItems = new SparseBooleanArray();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display);

        SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
        userId = sharedPreferences.getInt("user_id", -1);

        boolean smsPermissionGranted = sharedPreferences.getBoolean("sms_permission_granted_" + userId, false);

        databaseHelper = new DatabaseHelper(this);
        gridView = findViewById(R.id.InventoryTracker);
        Button buttonAddData = findViewById(R.id.buttonAddData);
        LinearLayout rowLayout = findViewById(R.id.rowLayout);
        Button buttonDeleteData = findViewById(R.id.buttonDeleteData);
        Button buttonEditData = findViewById(R.id.buttonEditData);
        Button buttonLogout = findViewById(R.id.buttonLogout);

        ArrayList<Item> itemList = databaseHelper.getAllItems(userId);
        itemAdapter = new ItemAdapter(this, itemList);
        gridView.setAdapter(itemAdapter);
        gridView.setOnItemClickListener(this);

        //This will use the permission response to enable or disable the SMS alert feature
        if (smsPermissionGranted) {
            //This is when permission is granted and enable SMS alert feature
            for (Item item : itemList) {
                if (item.getQuantity() < 5) {
                    sendSMSAlert(item);
                }
            }
        }

        //This will set click listeners for buttons
        buttonAddData.setOnClickListener(v -> {
            //This will handle adding data logic here
            openAddDataDialog();
        });

        buttonDeleteData.setOnClickListener(v -> deleteSelectedItem());
        buttonEditData.setOnClickListener(v -> editSelectedItem());

        //This will set click listener for GridView items
        gridView.setOnItemClickListener((parent, view, position, id) -> {
            //This will clear the selection status of all items
            selectedItems.clear();
            for (int i = 0; i < gridView.getCount(); i++) {
                gridView.getChildAt(i).setBackgroundColor(Color.TRANSPARENT);
            }

            //This will change the selection status of the clicked item
            boolean isSelected = !selectedItems.get(position, false);
            selectedItems.put(position, isSelected);

            //This will update the view to show the selection status
            if (isSelected) {
                view.setBackgroundColor(Color.parseColor("#FFC107")); // Use your desired color here
            } else {
                view.setBackgroundColor(Color.TRANSPARENT);
            }
            //This will notify the adapter that the data has changed
            itemAdapter.notifyDataSetChanged();
        });
        buttonLogout.setOnClickListener(v -> {

            //This will start LoginActivity to return back to the login screen
            Intent intent = new Intent(DataDisplayActivity.this, LoginActivity.class);
            startActivity(intent);
            finish(); //This will close the current activity
        });
    }

    private void openAddDataDialog() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.edit_item_dialog, null);
        dialogBuilder.setView(dialogView);

        final EditText editTextName = dialogView.findViewById(R.id.editTextName);
        final EditText editTextQuantity = dialogView.findViewById(R.id.editTextQuantity);
        final EditText editTextPrice = dialogView.findViewById(R.id.editTextPrice);

        dialogBuilder.setTitle("Add New Item");
        dialogBuilder.setPositiveButton("Save", (dialog, whichButton) -> {
            String itemName = editTextName.getText().toString();
            int quantity = Integer.parseInt(editTextQuantity.getText().toString());
            double price = Double.parseDouble(editTextPrice.getText().toString());

            //This will retrieve user_id from shared preferences
            SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
            int userId = sharedPreferences.getInt("user_id", -1);

            if (userId != -1) {
                //This will add the new item to the database with the user ID
                long newRowId = databaseHelper.addItem(itemName, quantity, price, userId);

                if (newRowId != -1) {
                    //This will update the GridView adapter with the new data
                    itemAdapter.addItem(new Item((int) newRowId, itemName, quantity, price));
                    itemAdapter.notifyDataSetChanged();
                } else {
                    //This will send an error message of adding the item
                    Toast.makeText(DataDisplayActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialogBuilder.setNegativeButton("Cancel", null);
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        //This will handle item click here
        selectedItems.put(position, !selectedItems.get(position));
        itemAdapter.notifyDataSetChanged();
    }

    void deleteSelectedItem() {

        //This will retrieve user_id from shared preferences
        SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
        int userId = sharedPreferences.getInt("user_id", -1);

        if (userId != -1) {
                    int position = getSelectedItemPosition();
                    Item itemToDelete = (Item) itemAdapter.getItem(position);
                    long deleteRowId = databaseHelper.deleteItem(itemToDelete);
                    if (deleteRowId != -1) {
                        //This will update the GridView adapter with the new data
                        itemAdapter.deleteItem(itemToDelete);
                        itemAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(DataDisplayActivity.this, "Error deleting item", Toast.LENGTH_SHORT).show();
                    }
        }
            refreshGridView(); //This will refresh the gridView after the item has been deleted
    }

    private void refreshGridView() {
        itemAdapter.clear();
        itemAdapter.addAll(databaseHelper.getAllItems(userId));
        gridView.clearChoices();
        itemAdapter.notifyDataSetChanged();
    }

    private void editSelectedItem() {
        int selectedItemPosition = getSelectedItemPosition();

        if (selectedItemPosition != -1) {
            //This will get the selected item from the adapter
            Item selectedItem = (Item) itemAdapter.getItem(selectedItemPosition);
            //This will open the edit dialog with the selected item's details
            openEditDataDialog(selectedItem);
        } else {
            //This will send an notification if an item is not selected.
            Toast.makeText(this, "Please select an item to edit", Toast.LENGTH_SHORT).show();
        }
    }

    private int getSelectedItemPosition() {
        for (int i = 0; i < selectedItems.size(); i++) {
            int key = selectedItems.keyAt(i);
            if (selectedItems.get(key)) {
                return key;
            }
        }
        return -1; //No item was selected
    }

    private void openEditDataDialog(Item itemToEdit) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.edit_item_dialog, null);
        dialogBuilder.setView(dialogView);

        final EditText editTextName = dialogView.findViewById(R.id.editTextName);
        final EditText editTextQuantity = dialogView.findViewById(R.id.editTextQuantity);
        final EditText editTextPrice = dialogView.findViewById(R.id.editTextPrice);

        //This will set the current item's details in the dialog's EditText fields
        editTextName.setText(itemToEdit.getItemName());
        editTextQuantity.setText(String.valueOf(itemToEdit.getQuantity()));
        editTextPrice.setText(String.valueOf(itemToEdit.getPrice()));

        dialogBuilder.setTitle("Edit Item");
        dialogBuilder.setPositiveButton("Save", (dialog, whichButton) -> {
            //This will update the item's details in the database and adapter

            SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
            int userId = sharedPreferences.getInt("user_id", -1);

            String newName = editTextName.getText().toString();
            int newQuantity = Integer.parseInt(editTextQuantity.getText().toString());
            double newPrice = Double.parseDouble(editTextPrice.getText().toString());

            itemToEdit.setItemName(newName);
            itemToEdit.setQuantity(newQuantity);
            itemToEdit.setPrice(newPrice);
            int selectedItemPosition = getSelectedItemPosition();
            Item itemToUpdate = (Item) itemAdapter.getItem(selectedItemPosition);
            long UpdateRowId = databaseHelper.updateItem(itemToUpdate, newName,newQuantity,newPrice);
            if (UpdateRowId != -1) {
                //This will update the GridView adapter with the new data
                itemAdapter.deleteItem(itemToUpdate);
                itemAdapter.notifyDataSetChanged();
            } else {
                Toast.makeText(DataDisplayActivity.this, "Error editing item", Toast.LENGTH_SHORT).show();
            }
            //This will update the gridView with the edited data
            refreshGridView();
        });
        dialogBuilder.setNegativeButton("Cancel", null);
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }

    private void sendSMSAlert(Item item) {
        String phoneNumber = "15551234567"; //This is the number of the emulated phone
        String message = "Alert: Item " + item.getItemName() +
                " is running low! Only " + item.getQuantity() + " left!";

        //This will check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            //If Permission is granted then this will send SMS
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "Alert sent for " + item.getItemName(), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS!", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }

        } else {
            //If no permission when it will ask the user
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{android.Manifest.permission.SEND_SMS},
                    100 //Any number to identify this request later
            );
            Toast.makeText(this, "Please allow SMS permission to send alerts.", Toast.LENGTH_SHORT).show();
        }
    }
}
