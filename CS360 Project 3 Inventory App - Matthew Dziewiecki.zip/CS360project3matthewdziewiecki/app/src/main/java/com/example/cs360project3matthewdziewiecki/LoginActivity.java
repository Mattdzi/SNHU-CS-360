package com.example.cs360project3matthewdziewiecki;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LoginActivity extends AppCompatActivity {
    private EditText editUsername;
    private EditText editPassword;
    private DatabaseHelper databaseHelper;
    //This can change the value to any unique integer

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_display);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);

        databaseHelper = new DatabaseHelper(this);

        btnLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString();
            String password = editPassword.getText().toString();

            //This will perform the login validation
            User user = databaseHelper.getUserByUsername(username);
            int userId = user.getId();
            if (user.getPassword().equals(password)) {
                //If successful login, this will then proceed to the next screen or action

                SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("user_id", user.getId()); //This is assuming user class has getId() method
                editor.apply();

                showPermissionDialog(userId);
            } else {
                //If it is an Invalid login, it will show this error message
                Toast.makeText(LoginActivity.this, "Invalid login credentials", Toast.LENGTH_SHORT).show();
            }
        });

        btnCreateAccount.setOnClickListener(v -> {
            //This will open the create account screen or activity here
            Intent intent = new Intent(LoginActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });
    }

    private void showPermissionDialog(int userId) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.sms_permission_dialog, null);
        dialogBuilder.setView(dialogView);

        Button buttonAcceptPermission = dialogView.findViewById(R.id.buttonAcceptPermission);
        Button buttonDenyPermission = dialogView.findViewById(R.id.buttonDenyPermission);

        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();

        buttonAcceptPermission.setOnClickListener(v -> {
            //This will store the permission response as granted for the current user
            SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("sms_permission_granted_" + userId, true);
            editor.apply();

            proceedToDataDisplay();
            alertDialog.dismiss();
        });

        buttonDenyPermission.setOnClickListener(v -> {
            //This will store the permission response as denied for the current user
            SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("sms_permission_granted_" + userId, false);
            editor.apply();

            proceedToDataDisplay();
            alertDialog.dismiss();
        });
    }

    private void proceedToDataDisplay() {
        Intent intent = new Intent(LoginActivity.this, DataDisplayActivity.class);
        startActivity(intent);
        finish();
    }
}